package com.dao;

import com.model.Customer;

public interface CustomerDao {
      String addCustomer(Customer customer);
}
