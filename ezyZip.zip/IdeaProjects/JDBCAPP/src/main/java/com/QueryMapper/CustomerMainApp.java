package com.QueryMapper;

import com.dao.CustomerDao;
import com.dao.CustomerDaoImpl;
import com.model.Customer;

import java.time.LocalDate;

public class CustomerMainApp {


        public static void main(String[] args) {
            CustomerDao customerDao = new CustomerDaoImpl();
            Customer customer = new Customer();
            customer.setCustomerId(1);
            customer.setCustomerName("Shahnawaz");
            customer.setEmail("s@gmail.com");
            customer.setMobile(9999106211L);
            customer.setBirthDate(LocalDate.now());
            customerDao.addCustomer(customer);

        }

    }


