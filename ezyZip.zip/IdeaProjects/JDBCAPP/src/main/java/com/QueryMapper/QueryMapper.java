package com.QueryMapper;


public interface QueryMapper {

   public static String ADD_CUSTOMER
            ="INSERT INTO Customer(customerId,customerName,birthDate,mobile,email) VALUES (?,?,?,?,?)";
}



