package com.PracticeQue;

import java.util.Scanner;
import java.util.stream.IntStream;

public class PrimeNumber {

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number to check: ");
        int numberToCheckForPrime = sc.nextInt();
        boolean result = isPrime(numberToCheckForPrime);
        if (result) {
            System.out.println(numberToCheckForPrime + " is a prime number");
        } else {
            System.out.println(numberToCheckForPrime + " is not a prime number ");
        }
    }

    private static boolean isPrime(int number) {
        return number > 1 && IntStream.range(2, number).noneMatch(i -> number % i == 0);
    }
}

