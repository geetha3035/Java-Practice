package com.PracticeQue;

public interface Mod {
       boolean isEven(int num) ;

}
