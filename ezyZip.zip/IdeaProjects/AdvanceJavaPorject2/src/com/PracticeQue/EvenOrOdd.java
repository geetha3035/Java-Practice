package com.PracticeQue;

import java.util.Scanner;

public class EvenOrOdd implements Mod {
    public boolean isEven(int num) {
        Mod even = (number) -> {
            if ((number % 2) == 0) {
                return true;
            } else {
                return false;
            }
        };
        return even.isEven(num);
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number to check whether even or odd");
        int num = sc.nextInt();
        EvenOrOdd e = new EvenOrOdd();
        boolean ev = e.isEven(num);
        if (ev) {
            System.out.println(num + " is even");
        } else {
            System.out.println(num + " is odd");
        }

    }
}
