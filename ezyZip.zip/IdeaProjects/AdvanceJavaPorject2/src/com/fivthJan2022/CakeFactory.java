package com.fivthJan2022;

public class CakeFactory {

    //use getPlan method to get object of type Plan
    public Cake getCake(String cakeType){
        if(cakeType == null){
            return null;
        }
        if(cakeType.equalsIgnoreCase("BlueBerry")) {
            return new BlueBerry();
        }
        else if(cakeType.equalsIgnoreCase("BlackForest")){
            return new BlackForest();
        }
        else if(cakeType.equalsIgnoreCase("LitchiGateaux")) {
            return new LitchiGateaux();
        }
        return null;
    }
}


