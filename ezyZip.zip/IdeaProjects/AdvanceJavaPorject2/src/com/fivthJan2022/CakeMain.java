package com.fivthJan2022;

import java.io.IOException;
import java.util.Scanner;

public class CakeMain {
    public static void main(String args[]) throws IOException {
        Scanner sc = new Scanner(System.in);
        CakeFactory cakeFactory = new CakeFactory();
        System.out.println("Enter cake type");
        String cake = sc.next();
        Cake c = cakeFactory.getCake(cake);
        System.out.println("Cake Name: " + c.getName() +"\n"+ "Cake Type :" + c.getType()+"\n" + "Cake Price: " + c.getPrice());

    }
}
