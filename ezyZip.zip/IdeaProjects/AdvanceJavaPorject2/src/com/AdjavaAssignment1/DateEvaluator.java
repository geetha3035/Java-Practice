package com.AdjavaAssignment1;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;


public class DateEvaluator {


    Scanner sc = new Scanner(System.in);

    public LocalDate add(int days) {
        return (LocalDate.of(sc.nextInt(), sc.nextInt(), sc.nextInt()).plusDays(days));
    }

    public LocalDate sub(int days) {
        return (LocalDate.of(sc.nextInt(), sc.nextInt(), sc.nextInt()).minusDays(days));
    }

    //    public LocalDate add(LocalDate date1, LocalDate date2) {
//        return (LocalDate.of(date1).toString() - LocalDate.of(date2).toString());
//    }
//
    public long sub() {
        System.out.println("Enter the to days to get difference in days");
        LocalDate firstDate = LocalDate.of(sc.nextInt(), sc.nextInt(), sc.nextInt());
        LocalDate secondDate = LocalDate.of(sc.nextInt(), sc.nextInt(), sc.nextInt());
        int days1 = (int) ChronoUnit.DAYS.between(firstDate, secondDate);
        return days1;
    }
}

