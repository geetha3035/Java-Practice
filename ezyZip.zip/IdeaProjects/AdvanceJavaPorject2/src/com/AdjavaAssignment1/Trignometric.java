package com.AdjavaAssignment1;

enum Trignometricop {
    SIN, COS, TAN
}

public class Trignometric {

    Trignometricop trignometricop;

    public Trignometric(Trignometricop trignometricop) {
        this.trignometricop = trignometricop;
    }

    public void trigonometricOperations(int num1) {
        switch (trignometricop) {
            case SIN:
                System.out.println("sin(" + num1 + ")" + " = " + (int) Math.sin(num1));
                break;

            case COS:
                System.out.println("sin(" + num1 + ")" + " = " + (int) Math.cos(num1));
                break;

            case TAN:
                System.out.println("sin(" + num1 + ")" + " = " + (int) Math.tan(num1));
                break;

            default:
                System.out.println("Invalid operation selected in Trigonometric operations");
                break;
        }
    }

}
