package com.AdjavaAssignment1;


public abstract class Addition implements Arithmetic {

    public static int add(int num1, int num2) {
        Arithmetic addOp = (number1, number2) -> (number1 + number2);
        return addOp.operate(num1, num2);
    }

}
