package com.AdjavaAssignment1;

enum Scientificop {
    ABS, SQRT, FACTORIAL
}

public class Scientific {

    Scientificop scientificop;

    public Scientific(Scientificop scientificop) {
        this.scientificop = scientificop;
    }

    public void scientificOperations(int num1) {
        switch (scientificop) {
            case ABS:
                System.out.println("Absolute value of " + num1 + " is " + Math.abs(num1));
                break;

            case SQRT:
                System.out.println("Square root of " + num1 + " is " + (int) Math.sqrt(num1));
                break;

            case FACTORIAL:
                int fact = 1, i = 1;
                int num = 5;
                while (i <= num) {
                    fact = fact * i;
                    i++; //increment i by 1
                }
                System.out.println("Factorial of " + num1 + " is " + fact);
                break;

            default:
                System.out.println("Invalid operation selected in Scientific operations");
                break;
        }
    }

}
