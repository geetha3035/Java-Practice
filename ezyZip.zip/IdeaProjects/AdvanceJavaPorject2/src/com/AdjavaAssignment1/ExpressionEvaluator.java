package com.AdjavaAssignment1;


public class ExpressionEvaluator {
    public static void main(String args[]) {
        String str = "10+sin(60)+sqrt(4)";
        if (str.contains("+") || str.contains("-") || str.contains("/") || str.contains("*") || str.contains("%")) {
            String[] strSpilt = str.split("\\+");
//            for (int i = 0; i < strSpilt.length; i++) {
//            }

        }

    }

}
