package com.AdjavaAssignment1;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class CalculatorMain {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome" + "\n" + "This are three operations available in the scientific calculators" + "\n" + "Please choose the operation:");
        System.out.println("Enter type of operations from below list:\n" + "* Arithmetic" + "\n" + "* Scientific" + "\n" + "* Trigonometric ");
        String choice = sc.next();
        switch (choice) {
            case "Arithmetic":
                System.out.println("Enter type of Arithmetic operations from below list:\n" + "* Addition(+)" + "\n" + "* Subtraction(-)" + "\n" + "* Multiplication(*) " + "\n" + "* Division(/)" + "\n" + "* Modulus(%)");
                String operation = sc.next();
                System.out.println("Enter the Two number to perform Arithmetic Operations:\n");
                int num1 = sc.nextInt();
                int num2 = sc.nextInt();
                if (operation.equals("Addition") || operation.equals("+")) {
                    int add = Addition.add(num1, num2);
                    System.out.println("Addition of " + num1 + "," + num2 + " = " + add);
                    break;
                } else if (operation.equals("Subtraction") || operation.equals("-")) {
                    int sub = Subtraction.sub(num1, num2);
                    System.out.println("Subtraction of " + num1 + "," + num2 + " = " + sub);
                    break;
                } else if (operation.equals("Multiplication") || operation.equals("*")) {
                    int mul = Multiplication.mul(num1, num2);
                    System.out.println("Multiplication of " + num1 + "," + num2 + " = " + mul);
                    break;
                } else if (operation.equals("Division") || operation.equals("/")) {
                    int quotient = Division.div(num1, num2);
                    System.out.println("Division of " + num1 + "," + num2 + " = " + quotient);
                    break;
                } else if (operation.equals("Modulus") || operation.equals("%")) {
                    int remainder = Module.mod(num1, num2);
                    System.out.println("Modulus of " + num1 + "," + num2 + " = " + remainder);
                    break;
                }
            case "Scientific":
                System.out.println("Enter type of Scientific operations from below list:\n" + "* ABS" + "\n" + "* SQRT" + "\n" + "* FACTORIAL " + "\n");
                String operation1 = sc.next();
                System.out.println("Enter a Number to Perform Scientific Operations");
                int num = sc.nextInt();
                if (operation1.equals("ABS")) {
                    Scientific abs = new Scientific(Scientificop.ABS);
                    abs.scientificOperations(num);
                } else if (operation1.equals("SQRT")) {
                    Scientific sqrt = new Scientific(Scientificop.SQRT);
                    sqrt.scientificOperations(num);
                } else if (operation1.equals("FACTORIAL")) {
                    Scientific fact = new Scientific(Scientificop.FACTORIAL);
                    fact.scientificOperations(num);
                }
                break;
            case "Trigonometric":
                System.out.println("Enter type of Trigonometric operations from below list:\n" + "* SIN" + "\n" + "* COS" + "\n" + "* TAN " + "\n");
                String operation2 = sc.next();
                System.out.println("Enter a Number to Perform Trigonometric Operations");
                int num3 = sc.nextInt();
                if (operation2.equals("SIN")) {
                    Trignometric sin = new Trignometric(Trignometricop.SIN);
                    sin.trigonometricOperations(num3);
                } else if (operation2.equals("COS")) {
                    Trignometric cos = new Trignometric(Trignometricop.COS);
                    cos.trigonometricOperations(num3);
                } else if (operation2.equals("TAN")) {
                    Trignometric tan = new Trignometric(Trignometricop.TAN);
                    tan.trigonometricOperations(num3);
                }
                break;
            case "Arithmetic,Scientific":

            case "Arithmetic,Scientific,Trigonometric":

                break;
            case "DateEvaluator":
                int days = sc.nextInt();
                DateEvaluator d = new DateEvaluator();
                d.add(days);
                d.sub(days);
                d.sub();
//              d.add(LocalDate.parse("20-10-2022"), LocalDate.parse("07-10-2022"));
                break;
            default:
                System.out.println("Enter valid choice");
                break;
        }
    }
}






