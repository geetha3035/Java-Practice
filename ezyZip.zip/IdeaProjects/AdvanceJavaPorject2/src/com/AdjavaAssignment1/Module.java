package com.AdjavaAssignment1;

public abstract class Module implements Arithmetic {

    public static int mod(int num1, int num2) {
        Arithmetic modOp = (number1, number2) -> {
            int mod = 0;
            mod = number1 % number2;
            return mod;
        };

        return modOp.operate(num1, num2);
    }

}
