package com.AdjavaAssignment1;

public abstract class Division implements Arithmetic {
    public static int div(int num1, int num2) {

        Arithmetic divOp = (number1, number2) -> {
            int quotient = 0;
            try {
                quotient = number1 / number2;
            } catch (ArithmeticException e) {
                System.out.println(e);
            }
            return quotient;
        };
        return divOp.operate(num1, num2);
    }
}
