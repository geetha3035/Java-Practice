package com.AdjavaAssignment1;

public abstract class Subtraction implements Arithmetic {

    public static int sub(int num1, int num2) {

        Arithmetic subOp = (number1, number2) -> {
            if (number1 > number2) {
                return (number1 - number2);
            } else {
                return (number2 - number1);
            }

        };
        return subOp.operate(num1, num2);
    }

}
