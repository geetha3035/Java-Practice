package com.AdjavaAssignment1;

public abstract class Multiplication implements Arithmetic {

    public static int mul(int num1, int num2) {

        Arithmetic mulOp = (number1, number2) -> {
            if (number1 == 0 && number2 == 0) {
                return (0);
            } else {
                return (number1 * number2);
            }
        };
        return mulOp.operate(num1, num2);

    }

}
