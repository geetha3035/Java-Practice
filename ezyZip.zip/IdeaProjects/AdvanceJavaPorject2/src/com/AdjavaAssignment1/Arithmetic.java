package com.AdjavaAssignment1;

@FunctionalInterface
public interface Arithmetic {
    int operate(int num1, int num2);

}
