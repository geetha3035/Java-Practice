package com.Assignment2;


public class Employee  {
    private int empId;
    private String empName;
    private int age;
    private String jobTitle;
    private double salary;
    private String department;

    //Parameterized constructor
    public Employee(int empId, String empName, int age, String jobTitle, double salary, String department) {
        this.empId = empId;
        this.empName = empName;
        this.age = age;
        this.jobTitle = jobTitle;
        this.salary = salary;
        this.department = department;
    }


    //Setters and Getters Methods
    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }
    //To String method


    @Override
    public String toString() {
        return "Employee{" +
                "empId=" + empId +
                ", empName='" + empName + '\'' +
                ", age=" + age +
                ", jobTitle='" + jobTitle + '\'' +
                ", salary=" + salary +
                ", department='" + department + '\'' +
                '}';
    }
    public  String showDetails(){
        return "Employee{" +
            "empId=" + empId +
                    ", empName='" + empName + '\'' +
                    ", age=" + age +
                    ", jobTitle='" + jobTitle + '\'' +
                    ", salary=" + salary +
                    ", department='" + department + '\'' +
                    '}';
    }
}
