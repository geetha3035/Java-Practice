package com.Assignment2;

import java.util.*;
import java.util.stream.Collectors;

public class EmployeeMain {
    public static void main(String[] args) {
        Employee emp1 = new Employee(121, "Ram", 21, "SE", 20000, "Marketing");
        Employee emp2 = new Employee(122, "Sri", 22, "SDE", 50000, "Development");
        Employee emp3 = new Employee(123, "Siri", 23, "SE-II", 30000, "IT");
        Employee emp4 = new Employee(124, "Gee", 25, "Director", 80000, "IT");
        Employee emp5 = new Employee(125, "squid", 26, "Manager", 40000, "Testing");
        Employee emp6 = new Employee(126, "Han", 23, "Associate", 50000, "Finance");
        Employee emp7 = new Employee(127, "Ling Lan", 26, "SDE", 50000, "IT");
        Employee emp8 = new Employee(128, "Sam", 24, "SE-II", 30000, "Testing");
        Employee emp9 = new Employee(129, "Qing", 30, "Director", 60000, "IT");
        Employee emp10 = new Employee(130, "Nan Wei", 21, "SE", 10000, "Testing");

        List<Employee> empList = new ArrayList<Employee>();
        empList.add(emp1);
        empList.add(emp2);
        empList.add(emp3);
        empList.add(emp4);
        empList.add(emp5);
        empList.add(emp6);
        empList.add(emp7);
        empList.add(emp8);
        empList.add(emp9);
        empList.add(emp10);


        System.out.println("================***Group Employee By Job Title***=====");
        Map<String, List<Employee>> groupedEmployeeByJobTitle = empList.stream().collect(Collectors.groupingBy(Employee::getJobTitle));
        System.out.println("[" + groupedEmployeeByJobTitle + " ];");

        System.out.println("================***Group Employee By Department***=====");
        Map<String, List<Employee>> groupedEmployeeByDepartment = empList.stream().collect(Collectors.groupingBy(Employee::getDepartment));
        System.out.println("[" + groupedEmployeeByDepartment + "];");

        System.out.println("================***Group Employee with maximum salary ***=====");
        System.out.println(empList.stream().filter(emp -> emp.getSalary() > 0f).max(Comparator.comparing(Employee::getSalary)));

        Optional<Employee> emp = empList.stream().collect(Collectors.maxBy(Comparator.comparingDouble(Employee::getSalary)));
        System.out.println(emp);

        System.out.println("================***top 5 Employee with salary ***=====");
        empList.stream().filter(e -> e.getSalary() > 0).limit(5).sorted(Comparator.comparingDouble(Employee::getSalary).reversed()).forEach(System.out::println);


        System.out.println("================***Display all Directors***=====");
        System.out.println(empList.stream().filter(e -> e.getJobTitle().equals("Director")).collect(Collectors.groupingBy(Employee::getJobTitle)));
        System.out.println(empList.stream().collect(Collectors.summarizingDouble(Employee::getSalary)));


    }

}
