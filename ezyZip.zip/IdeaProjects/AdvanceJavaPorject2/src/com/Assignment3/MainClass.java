package com.Assignment3;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.BinaryOperator;
import java.util.function.Function;
import java.util.stream.Collectors;

public class MainClass {


    public static void main(String[] args) {

        //customer related
        Customer cust1 = new Customer(1, "Stefan Walker", 1);
        Customer cust2 = new Customer(2, "Daija Von", 1);
        Customer cust3 = new Customer(3, "Ariane Rodriguez", 1);
        Customer cust4 = new Customer(4, "Marques Nikolaus", 2);
        Customer cust5 = new Customer(5, "Rachelle Greenfelder", 0);
        Customer cust6 = new Customer(6, "Larissa White", 2);
        Customer cust7 = new Customer(7, "Fae Heidenreich", 1);
        Customer cust8 = new Customer(8, "Dino Will", 2);
        Customer cust9 = new Customer(9, "Eloy Stroman", 1);
        Customer cust10 = new Customer(10, "Brisa O'Connell", 1);

        //product related
        Product prod1 = new Product(1, "omnis quod consequatur", "Games", 184.83);
        Product prod2 = new Product(2, "vel libero suscipit", "Toys", 12.66);
        Product prod3 = new Product(3, "non nemo iure", "Grocery", 498.02);
        Product prod4 = new Product(4, "voluptatem voluptas aspernatur", "Toys", 536.80);
        Product prod5 = new Product(5, "animi cum rem", "Games", 458.20);
        Product prod6 = new Product(6, "dolorem porro debitis", "Toys", 146.52);
        Product prod7 = new Product(7, "aspernatur rerum qui", "Books", 656.42);
        Product prod8 = new Product(8, "deleniti earum et", "Baby", 41.46);
        Product prod9 = new Product(9, "voluptas ut quidem", "Books", 697.57);
        Product prod10 = new Product(10, "eos sed debitis", "Baby", 366.90);
        Product prod11 = new Product(11, "laudantium sit nihil", "Toys", 95.50);
        Product prod12 = new Product(12, "ut perferendis corporis", "Grocery", 302.19);
        Product prod13 = new Product(13, "sint voluptatem ut", "Toys", 295.37);
        Product prod14 = new Product(14, "quos sunt ipsam", "Grocery", 534.64);
        Product prod15 = new Product(15, "qui illo error", "Baby", 623.58);
        Product prod16 = new Product(16, "aut ex ducimus", "Books", 551.39);
        Product prod17 = new Product(17, "accusamus repellendus minus", "Books", 240.58);
        Product prod18 = new Product(18, "aut accusamus quia", "Baby", 881.38);
        Product prod19 = new Product(19, "doloremque incidunt sed", "Games", 988.49);
        Product prod20 = new Product(20, "libero omnis velit", "Baby", 177.61);
        Product prod21 = new Product(21, "consectetur cupiditate sunt", "Toys", 95.46);
        Product prod22 = new Product(22, "itaque ea qui", "Baby", 677.78);
        Product prod23 = new Product(23, "non et nulla", "Grocery", 70.49);
        Product prod24 = new Product(24, "veniam consequatur et", "Books", 893.44);
        Product prod25 = new Product(25, "magnam adipisci voluptate", "Grocery", 366.13);
        Product prod26 = new Product(26, "reiciendis consequuntur placeat", "Toys", 359.27);
        Product prod27 = new Product(27, "dolores ipsum sit", "Toys", 786.99);
        Product prod28 = new Product(28, "ut hic tempore", "Toys", 316.09);
        Product prod29 = new Product(29, "quas quis deserunt", "Toys", 772.78);
        Product prod30 = new Product(30, "excepturi nesciunt accusantium", "Toys", 911.46);

        List<Product> productList = new ArrayList<Product>();
        productList.add(prod1);
        productList.add(prod2);
        productList.add(prod3);
        productList.add(prod4);
        productList.add(prod5);
        productList.add(prod6);
        productList.add(prod7);
        productList.add(prod8);
        productList.add(prod9);
        productList.add(prod10);
        productList.add(prod11);
        productList.add(prod12);
        productList.add(prod13);
        productList.add(prod14);
        productList.add(prod15);
        productList.add(prod16);
        productList.add(prod17);
        productList.add(prod18);
        productList.add(prod19);
        productList.add(prod20);
        productList.add(prod21);
        productList.add(prod22);
        productList.add(prod23);
        productList.add(prod24);
        productList.add(prod25);
        productList.add(prod26);
        productList.add(prod27);
        productList.add(prod28);
        productList.add(prod29);
        productList.add(prod30);

        List<Product> productList1 = new ArrayList<Product>();
        productList1.add(prod1);
        productList1.add(prod3);

        List<Product> productList2 = new ArrayList<Product>();
        productList2.add(prod3);
        productList2.add(prod6);
        productList2.add(prod20);


        //order related
        Order order1 = new Order(1, "NEW", LocalDate.parse("2021-02-28"), LocalDate.parse("2021-03-08"), productList1, cust5);
        Order order2 = new Order(2, "NEW", LocalDate.parse("2021-02-28"), LocalDate.parse("2021-03-05"), productList1, cust3);
        Order order3 = new Order(3, "DELIVERED", LocalDate.parse("2021-04-10"), LocalDate.parse("2021-04-18"), productList1, cust5);
        Order order4 = new Order(4, "PENDING", LocalDate.parse("2021-03-22"), LocalDate.parse("2021-03-27"), productList1, cust3);
        Order order5 = new Order(5, "NEW", LocalDate.parse("2021-03-04"), LocalDate.parse("2021-03-12"), productList2, cust1);
        Order order6 = new Order(6, "DELIVERED", LocalDate.parse("2021-03-30"), LocalDate.parse("2021-04-07"), productList2, cust9);
        Order order7 = new Order(7, "PENDING", LocalDate.parse("2021-03-05"), LocalDate.parse("2021-03-09"), productList1, cust8);
        Order order8 = new Order(8, "NEW", LocalDate.parse("2021-03-27"), LocalDate.parse("2021-04-05"), productList1, cust4);
        Order order9 = new Order(9, "NEW", LocalDate.parse("2021-04-14"), LocalDate.parse("2021-04-18"), productList1, cust10);
        Order order10 = new Order(10, "NEW", LocalDate.parse("2021-03-10"), LocalDate.parse("2021-03-19"), productList1, cust8);
        Order order11 = new Order(11, "DELIVERED", LocalDate.parse("2021-04-01"), LocalDate.parse("2021-04-04"), productList2, cust1);
        Order order12 = new Order(12, "PENDING", LocalDate.parse("2021-02-24"), LocalDate.parse("2021-02-28"), productList2, cust5);
        Order order13 = new Order(13, "NEW", LocalDate.parse("2021-03-15"), LocalDate.parse("2021-03-21"), productList2, cust5);
        Order order14 = new Order(14, "PENDING", LocalDate.parse("2021-03-30"), LocalDate.parse("2021-04-07"), productList1, cust4);
        Order order15 = new Order(15, "DELIVERED", LocalDate.parse("2021-03-13"), LocalDate.parse("2021-03-14"), productList1, cust5);
        Order order16 = new Order(16, "NEW", LocalDate.parse("2021-03-13"), LocalDate.parse("2021-03-21"), productList2, cust1);
        Order order17 = new Order(17, "DELIVERED", LocalDate.parse("2021-03-31"), LocalDate.parse("2021-03-31"), productList1, cust6);
        Order order18 = new Order(18, "PENDING", LocalDate.parse("2021-03-25"), LocalDate.parse("2021-03-31"), productList1, cust9);
        Order order19 = new Order(19, "DELIVERED", LocalDate.parse("2021-02-28"), LocalDate.parse("2021-03-09"), productList1, cust9);
        Order order20 = new Order(20, "NEW", LocalDate.parse("2021-03-23"), LocalDate.parse("2021-03-30"), productList2, cust5);
        Order order21 = new Order(21, "DELIVERED", LocalDate.parse("2021-03-19"), LocalDate.parse("2021-03-24"), productList2, cust9);
        Order order22 = new Order(22, "NEW", LocalDate.parse("2021-02-27"), LocalDate.parse("2021-03-01"), productList2, cust5);
        Order order23 = new Order(23, "PENDING", LocalDate.parse("2021-04-19"), LocalDate.parse("2021-04-24"), productList1, cust4);
        Order order24 = new Order(24, "DELIVERED", LocalDate.parse("2021-03-24"), LocalDate.parse("2021-03-24"), productList2, cust1);
        Order order25 = new Order(25, "NEW", LocalDate.parse("2021-03-03"), LocalDate.parse("2021-03-10"), productList2, cust1);
        Order order26 = new Order(26, "NEW", LocalDate.parse("2021-03-17"), LocalDate.parse("2021-03-26"), productList2, cust10);
        Order order27 = new Order(27, "NEW", LocalDate.parse("2021-03-20"), LocalDate.parse("2021-03-25"), productList2, cust1);
        Order order28 = new Order(28, "DELIVERED", LocalDate.parse("2021-04-09"), LocalDate.parse("2021-04-16"), productList1, cust2);
        Order order29 = new Order(29, "PENDING", LocalDate.parse("2021-04-06"), LocalDate.parse("2021-04-08"), productList2, cust1);
        Order order30 = new Order(30, "DELIVERED", LocalDate.parse("2021-04-19"), LocalDate.parse("2021-04-20"), productList2, cust1);
        Order order31 = new Order(31, "NEW", LocalDate.parse("2021-03-03"), LocalDate.parse("2021-03-04"), productList2, cust3);
        Order order32 = new Order(32, "DELIVERED", LocalDate.parse("2021-03-15"), LocalDate.parse("2021-03-24"), productList1, cust2);
        Order order33 = new Order(33, "PENDING", LocalDate.parse("2021-04-18"), LocalDate.parse("2021-04-24"), productList1, cust1);
        Order order34 = new Order(34, "NEW", LocalDate.parse("2021-03-28"), LocalDate.parse("2021-03-28"), productList2, cust6);
        Order order35 = new Order(35, "NEW", LocalDate.parse("2021-03-15"), LocalDate.parse("2021-03-17"), productList1, cust1);
        Order order36 = new Order(36, "DELIVERED", LocalDate.parse("2021-03-04"), LocalDate.parse("2021-03-08"), productList1, cust2);
        Order order37 = new Order(37, "NEW", LocalDate.parse("2021-03-18"), LocalDate.parse("2021-03-25"), productList1, cust8);
        Order order38 = new Order(38, "NEW", LocalDate.parse("2021-04-11"), LocalDate.parse("2021-04-20"), productList2, cust8);
        Order order39 = new Order(39, "NEW", LocalDate.parse("2021-04-12"), LocalDate.parse("2021-04-17"), productList1, cust9);
        Order order40 = new Order(40, "PENDING", LocalDate.parse("2021-03-12"), LocalDate.parse("2021-03-12"), productList2, cust3);
        Order order41 = new Order(41, "NEW", LocalDate.parse("2021-02-24"), LocalDate.parse("2021-02-26"), productList1, cust5);
        Order order42 = new Order(42, "NEW", LocalDate.parse("2021-04-08"), LocalDate.parse("2021-04-14"), productList1, cust9);
        Order order43 = new Order(43, "NEW", LocalDate.parse("2021-03-03"), LocalDate.parse("2021-03-11"), productList1, cust3);
        Order order44 = new Order(44, "DELIVERED", LocalDate.parse("2021-03-12"), LocalDate.parse("2021-03-14"), productList1, cust4);
        Order order45 = new Order(45, "DELIVERED", LocalDate.parse("2021-04-01"), LocalDate.parse("2021-04-06"), productList2, cust1);
        Order order46 = new Order(46, "NEW", LocalDate.parse("2021-03-16"), LocalDate.parse("2021-03-22"), productList1, cust10);
        Order order47 = new Order(47, "PENDING", LocalDate.parse("2021-04-07"), LocalDate.parse("2021-04-12"), productList1, cust2);
        Order order48 = new Order(48, "NEW", LocalDate.parse("2021-04-05"), LocalDate.parse("2021-04-06"), productList2, cust2);
        Order order49 = new Order(49, "NEW", LocalDate.parse("2021-04-10"), LocalDate.parse("2021-04-13"), productList1, cust7);
        Order order50 = new Order(50, "NEW", LocalDate.parse("2021-03-18"), LocalDate.parse("2021-03-21"), productList2, cust9);

        List<Order> orderList = new ArrayList<Order>();
        orderList.add(order1);
        orderList.add(order2);
        orderList.add(order3);
        orderList.add(order4);
        orderList.add(order5);
        orderList.add(order6);
        orderList.add(order7);
        orderList.add(order8);
        orderList.add(order9);
        orderList.add(order10);
        orderList.add(order11);
        orderList.add(order12);
        orderList.add(order13);
        orderList.add(order14);
        orderList.add(order15);
        orderList.add(order16);
        orderList.add(order17);
        orderList.add(order18);
        orderList.add(order19);
        orderList.add(order20);
        orderList.add(order21);
        orderList.add(order22);
        orderList.add(order23);
        orderList.add(order24);
        orderList.add(order25);
        orderList.add(order26);
        orderList.add(order27);
        orderList.add(order28);
        orderList.add(order29);
        orderList.add(order30);
        orderList.add(order31);
        orderList.add(order32);
        orderList.add(order33);
        orderList.add(order34);
        orderList.add(order35);
        orderList.add(order36);
        orderList.add(order37);
        orderList.add(order38);
        orderList.add(order39);
        orderList.add(order40);
        orderList.add(order41);
        orderList.add(order42);
        orderList.add(order43);
        orderList.add(order44);
        orderList.add(order45);
        orderList.add(order46);
        orderList.add(order47);
        orderList.add(order48);
        orderList.add(order49);
        orderList.add(order50);

        System.out.println("=======***In product books price>100***======");
        productList.stream().filter(p -> p.getPrice() > 100 & p.getCategory().equals("Books")).sorted(Comparator.comparing(Product::getPrice)).forEach(System.out::println);

        System.out.println("=======***In order product category baby***======");
        productList.stream().filter(p -> p.getCategory().equals("Baby")).sorted(Comparator.comparing(Product::getPrice)).forEach(System.out::println);
        orderList.stream().map(o->(o.getProducts().stream().filter(p->p.getCategory().equalsIgnoreCase("Baby")).collect(Collectors.groupingBy(Product::getCategory)))).forEach(System.out::println);

        System.out.println("=======***In order product category toys and apply 10% discount***======");
        Function<Double, Double> applyingDiscount = x -> x - (10 / 100) * x;

        productList.stream().filter(p -> p.getCategory().equals("Toys")).reduce((<Product> applyingDiscount).collect(Collectors.groupingBy(Product::getPrice));

        System.out.println("=======***In order customer 2tire 1-02-2021 t0 01-04-2021***======");
        System.out.println(orderList.stream().filter((o->o.getCustomer().getTier()==2)).filter(o->o.getOrderDate().isAfter(LocalDate.parse("2021-02-01"))).filter(o->o.getOrderDate().isBefore(LocalDate.parse("2021-04-01"))).collect(Collectors.groupingBy(Order::getOrderDate)));

        //orderList.stream().filter(o->o.getTier().     .equals("Baby")).sorted(Comparator.comparing(Product::getPrice)).forEach(System.out::println);


        System.out.println("************cheapest book*********************");
        System.out.println(productList.stream().filter(p -> p.getCategory().equals("Books")).min(Comparator.comparing(Product::getPrice)));


    }
}
