package com.Ad.twenty7thDec2021;

public class MethodReference {

    int value;

    public MethodReference() {
        this.value = value;
    }

    public MethodReference(int value) {
        this.value = value;
    }


    public static void displayStatic() {
        System.out.println("Reference to Static Method");
    }

    public void displayNonStatic() {
        System.out.println("Reference to Non-Static Method");
    }

    public void displayConstructor(){
        System.out.println("Reference to constructor");
    }

    public static void main(String[] args) {
        //Reference to static method
        DisplayInformation dis = MethodReference::displayStatic;
        dis.display();


        //Reference to Instance  method
        DisplayInformation inst = new MethodReference()::displayNonStatic;
        inst.display();

        // Constructor Reference
        DisplayInformation constr = new MethodReference(10)::displayConstructor;
        constr.display();


    }

}
