package com.AdJava.Assignment;

public class Subtraction extends CalculatorArithmetic {

    public void sub(int num1, int num2) {

        Arithmetic subOp = (number1, number2) -> {
            if (number1 > number2) {
                return (number1 - number2);
            } else {
                return (number2 - number1);
            }
        };

    }

}
