package com.AdJava.Assignment;



public class CalculatorMain {
    public static void main(String[] args) {
        CalculatorChoice.pageDescription();

            }

        }


