package com.AdJava.Assignment;

public class CalculatorArithmetic {
    @FunctionalInterface
    interface  Arithmetic {
        int operation(int num1,int num2);
    }
}
