package com.AdJava.Assignment;

public class Addition extends CalculatorArithmetic {
    public void add(int num1, int num2) {
        Arithmetic addOp = (number1, number2) -> {return (number1 + number2);};

    }
}
