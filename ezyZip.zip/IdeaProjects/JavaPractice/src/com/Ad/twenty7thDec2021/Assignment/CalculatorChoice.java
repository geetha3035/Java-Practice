package com.AdJava.Assignment;

import java.util.Scanner;

public class CalculatorChoice {

    public static void pageDescription() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome" + "\n" + "This are three operations available in the scientific calculators" + "\n" + "Please choose the operation:");
        System.out.println("1.Arithmetic" + "\n" + "2.Trigonometric" + "\n" + "3.Geometric ");
        String choice = sc.next();
        switch (choice) {
            case "Arithmetic":
                System.out.println("add,sub,mul,div,mod");
                break;
            case "Trigonometric":
                System.out.println("sin,cos,tan");
                break;
            case "Geometric":
                System.out.println("factorial,swap,sqrt");
                break;
            default:
                System.out.println("Enter valid choice");
                break;

        }
    }
}
