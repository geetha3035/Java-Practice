package com.AdJava.Assignment;

public class Multiplication extends CalculatorArithmetic {

    public void mul(int num1, int num2) {

        Arithmetic mulOp = (number1, number2) -> {
            if (number1 == 0 && number2 == 0) {
                return 0;
            } else {
                return (number1 * number2);
            }
        };

    }
}
