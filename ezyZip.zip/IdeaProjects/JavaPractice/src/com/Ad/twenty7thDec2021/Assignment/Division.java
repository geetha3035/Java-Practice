package com.AdJava.Assignment;

public class Division extends CalculatorArithmetic {
    public void div(int num1, int num2) {

        Arithmetic divOp = (number1, number2) -> {
            try {
                return (number1 / number2);
            } catch (ArithmeticException e) {
                System.out.println("Divided by zero");
            }

            return (number1 / number2);
        };

    }

}
