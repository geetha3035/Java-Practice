//package com.Ad.twenty7thDec2021;
//
//public class EvenOrOdd {
//    interface Div {
//        static void isEven(int a) {
//        }
//
//        public static void main(String args[]) {
//
//
//            Div even = ((int a)
//                    -> {
//                if (a % 2 == 0) {
//                    System.out.println("even");
//                } else {
//                    System.out.println("Odd");
//                }
//                ;
//            });
//            EvenOrOdd e=new EvenOrOdd();
//            System.out.println(isEven(10)+" = "+ e.even(10));
//
//        }
//    }
//}
//
//
//
//
