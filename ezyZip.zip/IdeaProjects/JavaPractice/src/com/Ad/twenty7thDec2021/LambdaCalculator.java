package com.Ad.twenty7thDec2021;

class LambdaCalculator {
    interface Operation {
        int operate(int a, int b);
    }
    public int calculate(int a, int b, Operation o) {
        System.out.println(o.toString());
        return o.operate(a, b);
    }

    public static void main(String[] arg) {
        int x = 1;
        String s = "+";
        int y = 2;
        if (arg.length>0) x = Integer.parseInt(arg[0]);
        if (arg.length>1) s = arg[1];
        if (arg.length>2) y = Integer.parseInt(arg[2]);

        // Using a lambda expression
        Operation add = (int a, int b) -> {return a+b;};

        // Using anonymous class
        Operation subtract = new Operation() {
            public int operate(int a, int b) {return a-b;}
        };

        // Using a local class
        class Multiply implements Operation {
            public int operate(int a, int b) {return a*b;}
        }
        Operation multiply = new Multiply();

        LambdaCalculator c = new LambdaCalculator();
        if (s.equals("+"))
            System.out.println(x+s+y+" = "+c.calculate(x,y,add));
        else if (s.equals("-"))
            System.out.println(x+s+y+" = "+c.calculate(x,y,subtract));
        else if (s.equals("*"))
            System.out.println(x+s+y+" = "+c.calculate(x,y,multiply));
        else
            System.out.println(x+s+y+" = Undefined");
    }
}
