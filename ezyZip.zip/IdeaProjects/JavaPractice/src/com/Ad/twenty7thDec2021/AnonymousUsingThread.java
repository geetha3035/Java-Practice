package com.Ad.twenty7thDec2021;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class AnonymousUsingThread {
    public static void main(String[] args) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("One way to represents Anonymous");
            }
        }).start();

        // using lambda expression
        new Thread(() -> System.out.println("Lambda Expression using Thread")).start();

        //multiple statement in lambda expression
        new Thread(() -> {System.out.println("Lambda Expression using Thread");
            System.out.println("Lambda Expression using Thread");
        }).start();


        List<String> currencies = Arrays.asList("USD", "JPY", "EUR", "HKD", "INR", "AUD");
        System.out.println("Unsorted currencies ---" + currencies);
//Using lambda expression sort these currencies
/**
 Collections.sort(currencies,(String a,String b)->{return a.compareTo(b);});
 System.out.println(currencies);
 **/
        Collections.sort(currencies, (a, b) -> {
            return a.compareTo(b);
        });
        System.out.println(currencies);
        System.out.println("***********************************");
        for (String currency : currencies)
            System.out.println(currency);

        System.out.println("***********************************");
        currencies.forEach(c->System.out.println(c));


    }
}


