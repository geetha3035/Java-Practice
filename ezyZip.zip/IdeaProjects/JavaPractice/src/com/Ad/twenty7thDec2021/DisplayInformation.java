package com.Ad.twenty7thDec2021;

public interface DisplayInformation {

    void display();


}
