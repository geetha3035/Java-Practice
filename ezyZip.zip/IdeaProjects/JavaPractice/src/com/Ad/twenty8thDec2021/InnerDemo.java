package com.Ad.twenty8thDec2021;

public class InnerDemo {

    public static void main(String[] args) {
        OuterClass outerClass = new OuterClass();
        //Instantiating the inner class
        OuterClass.InnerClass innerClass= outerClass.new InnerClass();
        innerClass.display();

    }

}



