package com.Ad.twenty8thDec2021;

public interface OuterInterface {
    class InnerClassInsideInterface{

    }
}
