package com.Ad.twenty8thDec2021;

public abstract class Student {
    abstract void study();

}