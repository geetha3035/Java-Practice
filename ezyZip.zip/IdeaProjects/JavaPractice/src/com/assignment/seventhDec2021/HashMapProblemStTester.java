/*Given a HashMap of type<String, Double> that stores names and corresponding average marks of students in a class, find out who scored the maximum and minimum marks. Implement the logic inside findMaxMinScorers() method. The method should return a HashMap<String, Double> which contains the maximum marks and the student(s) who scored the marks followed by minimum marks and the students(s) who scored it.
Test the functionalities using the main() method of the Tester class.
*/
package com.assignment.seventhDec2021;

import java.util.HashMap;

public class HashMapProblemStTester extends HashMapProblemSt {
    public static void main(String args[]) {
        HashMap<String, Double> studentMarks = new HashMap<String, Double>();
        //lily=90.0  robin=68.0 marshall=76.5 neil=67.0  ted=92.0
        studentMarks.put("Lily", 90.0);
        studentMarks.put("Robin", 68.0);
        studentMarks.put("Marshall", 76.5);
        studentMarks.put("Neil", 67.0);
        studentMarks.put("Ted", 92.0);
        HashMap<String, Double> resultMap = findMaxMinScorers(studentMarks);
        System.out.println(resultMap);

        HashMap<String, Double> studentMarks1 = new HashMap<String, Double>();
        //lily=85.0  robin=78.5 marshall=86.0 neil=72.0  ted=86.0
        studentMarks1.put("Lily", 85.0);
        studentMarks1.put("Robin", 78.5);
        studentMarks1.put("Marshall", 86.0);
        studentMarks1.put("Neil", 72.0);
        studentMarks1.put("Ted", 86.0);
        HashMap<String, Double> resultMap1 = findMaxMinScorers(studentMarks1);
        System.out.println(resultMap1);

    }


}
