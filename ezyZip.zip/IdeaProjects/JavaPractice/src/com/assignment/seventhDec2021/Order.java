/* A restaurant keeps a track of all the orders using an ArrayList and a class Order. The class Order is implemented and provided to you.
You need to retrieve and return the list of items present in all the orders. Implement the logic inside getItems() method.
Test the functionalities using the main() method of the Tester class.
*/
package com.assignment.seventhDec2021;

import java.util.ArrayList;
import java.util.Collections;

public class Order {
    int orderNo;
    static boolean orderAcceptStatus = true;
    String itemNames;

    public Order() {
    }

    public Order(int orderNo, String itemNames) {
        this.orderNo = orderNo;
        this.itemNames = itemNames;
        this.orderAcceptStatus = orderAcceptStatus;
    }

    public int getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(int orderNo) {
        this.orderNo = orderNo;
    }

    public String getItemNames() {
        return itemNames;
    }

    public void setItemNames(String itemNames) {
        this.itemNames = itemNames;
    }


    public ArrayList getItems(String itemNames) {
        String[] itemNamesspilt = itemNames.split(",");
        ArrayList itemList = new ArrayList();

        Collections.addAll(itemList, itemNamesspilt);

        return itemList;

    }

}
