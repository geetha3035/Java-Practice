/*Given two linked lists that store integer values, return a linked list containing the common elements from both the lists. Implement the logic inside findCommonElements() method.
Test the functionalities using the main() method of the Tester class.
 */
package com.assignment.seventhDec2021;

import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class LinkedListTester {
    public <T> List<T> findCommonElements(List<T> listOne, List<T> listTwo)
    {
        List<T> list = new LinkedList<T>();
        for (T t : listOne)
        {
            if(listTwo.contains(t))
            {
                list.add(t);
            }
        }
        return list;
    }
    public static void main(String args[]) throws Exception {
        Scanner sc = new Scanner(System.in);

        //listOne = 10,12,21,1,53
        //list2Two= 11,21,25,53,47
        LinkedList<Integer> listOne = new LinkedList<Integer>();
        System.out.println("Enter  listOne elements");
        for (int i = 0; i < 5; i++) {
            listOne.add(sc.nextInt());
        }
        LinkedList<Integer> listTwo = new LinkedList<Integer>();

        System.out.println("Enter  listTwo elements");
        for (int i = 0; i < 5; i++) {
            listTwo.add(sc.nextInt());
        }
/*other way of initalizing LinkedList
       List<Integer> list1 = new LinkedList<Integer>(Arrays.asList(10,12,21,1,53));
       List<Integer> list2 = new LinkedList<Integer>(Arrays.asList(11,21,25,53,47));*/

        //Display the record from LinkedList
        System.out.println("===========================");
        System.out.println("Intersection of LinkedList.");
        System.out.println( new LinkedListTester().findCommonElements(listOne, listTwo));


    }

}
