/*Given two lists, concatenate the second list in reverse order to the end of the first list and return the concatenated list. Implement the logic inside concatenateLists() method.
Note: Use descendingIterator() method to iterate over the elements in reverse order. Test the functionalities using the main() method of the Tester class.
 */
package com.assignment.seventhDec2021;

import java.util.ArrayList;
import java.util.ListIterator;

public class ListIteratorProblemSt {

    public static void main(String args[]) {


        ArrayList listOne = new ArrayList();
        listOne.add("Hello");
        listOne.add(102);
        listOne.add(25);
        listOne.add(38.5);
        ListIterator iter = listOne.listIterator();
        while (iter.hasNext()) {
            System.out.print(iter.next()+"->");
        }
        ArrayList listTwo = new ArrayList();
        listTwo.add(150);
        listTwo.add(200);
        listTwo.add("A");
        listTwo.add("Welcome");
        ListIterator iter1 = listTwo.listIterator();
        while (iter1.hasNext()) {
            iter1.next();
        }
        while (iter1.hasPrevious()) {
            System.out.print(iter1.previous() + "->");
        }

        System.out.println();
        ArrayList listOne1 = new ArrayList();
        listOne1.add(50.5);
        listOne1.add("X");
        listOne1.add(125);
        listOne1.add("A");
        ListIterator iter2 = listOne1.listIterator();
        while (iter2.hasNext()) {
            System.out.print(iter2.next() + "->");
        }
        ArrayList listTwo1 = new ArrayList();
        listTwo1.add(150);
        listTwo1.add(165);
        listTwo1.add("Hello");
        listTwo1.add(25.7);
        ListIterator iter3 = listTwo1.listIterator();
        while (iter3.hasNext()) {
            iter3.next();
        }
        while (iter3.hasPrevious()) {
            System.out.print(iter3.previous() + "->");
        }


    }
}
