/*A restaurant keeps a track of all the orders using an ArrayList and a class Order. The class Order is implemented and provided to you.
You need to retrieve and return the list of items present in all the orders. Implement the logic inside getItems() method.
Test the functionalities using the main() method of the Tester class.
*/
package com.assignment.seventhDec2021;

import java.util.ArrayList;

public class ArrayListTester {
    public static void main(String args[]) {
        Order order1 = new Order(101, "FriedRice,Pasta,Tortilla");
        Order order2 = new Order(102, "Pizza,Pasta");
        Order order3 = new Order(103, "Burger,Sandwich,Pizza");
/*other way
        Order order1 = new Order(101,"FriedRice,Pasta,Tortilla",true);
        order1.setOrderNo(101);
        order1.setItemNames("FriedRice,Pasta,Tortilla");
        order1.setOrderAcceptStatus(true);
        Order order2 = new Order();
        order2.setOrderNo(102);
        order2.setItemNames("Pizza,Pasta");
        order2.setOrderAcceptStatus(true);
        Order order3 = new Order();
        order3.setOrderNo(103);
        order3.setItemNames("Burger,Sandwich,Pizza");
        order3.setOrderAcceptStatus(true);*/
/*      orders.add("Order("+order1.getOrderNo()+",itemNames=["+order1.getItemNames()+"],"+order1.isOrderAcceptStatus()+")");
        orders.add("Order("+order2.getOrderNo()+",itemNames=["+order2.getItemNames()+"],"+order2.isOrderAcceptStatus()+")");
        orders.add("Order("+order3.getOrderNo()+",itemNames=["+order3.getItemNames()+"],"+order3.isOrderAcceptStatus()+")");*/
        ArrayList orders = new ArrayList();
        orders.addAll(order1.getItems(order1.getItemNames()));
        orders.addAll(order2.getItems(order2.getItemNames()));
        orders.addAll(order3.getItems(order3.getItemNames()));
        System.out.println(orders);
        ArrayList orders1 = new ArrayList();
        Order order4 = new Order(911, "Burger,Pizza");
        Order order5 = new Order(912, "Cream,Cheese,Bread");
        orders1.addAll(order4.getItems(order4.getItemNames()));
        orders1.addAll(order5.getItems(order5.getItemNames()));
        System.out.println(orders1);

    }
}
