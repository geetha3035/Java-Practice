/* Given a linked list that stores integer values, remove the duplicate values and return a list containing unique values. Implement the logic inside removeDuplicates() method.
Test the functionalities using the main() method of the Tester class.
*/
package com.assignment.seventhDec2021;

import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Scanner;

public class LinkedListTest {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of LinkedList");
        int n = sc.nextInt();
        //list1 = 10 15  21 15  10
        //list2 = 51 45 45 15 82 51 10
        LinkedList<Integer> list = new LinkedList<Integer>();
        System.out.println("Enter  LinkedList elements");
        for (int i = 0; i < n; i++) {
            list.add(sc.nextInt());
        }

        LinkedHashSet resultSet = removeDuplicates(list);
        System.out.println(resultSet);

    }

    static LinkedHashSet removeDuplicates(LinkedList list) {
        LinkedHashSet resultSet = new LinkedHashSet();
        resultSet.addAll(list);
        return resultSet;
    }
}
