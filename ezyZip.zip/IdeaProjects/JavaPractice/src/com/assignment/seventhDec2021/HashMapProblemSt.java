/* Given a HashMap of type<String, Double> that stores names and corresponding average marks of students in a class, find out who scored the maximum and minimum marks. Implement the logic inside findMaxMinScorers() method. The method should return a HashMap<String, Double> which contains the maximum marks and the student(s) who scored the marks followed by minimum marks and the students(s) who scored it.
Test the functionalities using the main() method of the Tester class.
*/
package com.assignment.seventhDec2021;

import java.util.HashMap;
import java.util.*;

public class HashMapProblemSt {
    public static HashMap<String, Double> findMaxMinScorers(HashMap<String, Double> map1) {
        HashMap<String, Double> resultMap = new HashMap<>();


        Double maxValueinMap = (Collections.max(map1.values()));// This will return max value in the Hashmap
        for (Map.Entry<String, Double> entry : map1.entrySet()) {  // Itrate through hashmap
            if (entry.getValue() == maxValueinMap) {
                resultMap.put(entry.getKey(), map1.get(entry.getKey()));
            }
        }
        Double minValueInMap = (Collections.min(map1.values()));  // This will return max value in the Hashmap
        for (Map.Entry<String, Double> entry : map1.entrySet()) {  // Itrate through hashmap
            if (entry.getValue() == minValueInMap) {
                resultMap.put(entry.getKey(), map1.get(entry.getKey()));     // Print the key with max value
            }
        }
        return resultMap;

    }


}




