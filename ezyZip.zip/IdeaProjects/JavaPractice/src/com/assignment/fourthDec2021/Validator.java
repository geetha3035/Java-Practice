package com.assignment.fourthDec2021;

public class Validator extends Applicant {
    static boolean result;


    public Validator() {

    }

    public Validator(String name, String jobprofile, int age) {
        super(name, jobprofile, age);
//        this.name = name;
//        this.jobProfile = jobprofile;
//        this.age = age;
    }


    public boolean validateName(String name) {
        //Validate that the name is not null or empty. If the name is null or empty, return false, else return true.
        if (!name.isEmpty() && !name.equals(null)) {
            result = true;
        } else {
            result = false;
        }
        return result;
    }

    public boolean validateJobProfile(String jobProfile) {
        //Validate that the jobProfile is either 'Associate' or 'Clerk' or 'Executive'or 'Officer'. If the jobProfile is valid, return true, else return false. Perform case-insensitive comparison.
        if (jobProfile.equalsIgnoreCase("Associate") || jobProfile.equalsIgnoreCase("Clerk") || jobProfile.equalsIgnoreCase("Executive") || jobProfile.equalsIgnoreCase("Officer")) {
            result = true;
        } else {
            result = false;
        }
        return result;
    }

    public boolean validateAge(int age) {
        //Validate that the age is between 18 and 30 (both inclusive). If the age is valid, return true, else return false
        if (age >= 18 && age <= 30) {
            result = true;
        } else {
            result = false;
        }
        return result;
    }


    public boolean validate(Applicant applicant) throws InvalidNameException, InvalidJobProfileException, InvalidAgeException {
        //Validate the details of the applicant by calling the appropriate methods. If any validation fails, throw user defined exceptions based on the below
        if (validateName(applicant.name) && validateJobProfile(applicant.jobProfile) && validateAge(applicant.age)) {
            result = true;
        } else if (!validateName(applicant.name)) {
            result = false;
            throw new InvalidNameException("Invalid Name");
        } else if (!validateJobProfile(applicant.jobProfile)) {
            result = false;
            throw new InvalidJobProfileException("Invalid JobProfile");
        } else if (!validateAge(applicant.age)) {
            result = false;
            throw new InvalidAgeException("Invalid Age");
        } else {
            result = false;
        }
        return result;
    }
}
