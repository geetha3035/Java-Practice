package com.assignment.fourthDec2021;

public class InvalidNameException extends Exception {
    public InvalidNameException(String message) {
        super(message);
    }
}
