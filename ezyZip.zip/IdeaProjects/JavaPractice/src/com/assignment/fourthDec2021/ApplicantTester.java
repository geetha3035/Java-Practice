package com.assignment.fourthDec2021;

public class ApplicantTester {


    public static void main(String[] args) throws InvalidAgeException, InvalidNameException, InvalidJobProfileException {

        Validator applicant1 = new Validator("RamRaj", "Clerk", 20);
        if (applicant1.validate(applicant1)) {
            System.out.println("Application submitted successfully !");
        }
        Validator applicant2 = new Validator("", "SE", 35);
        applicant2.validate(applicant2);

    }
}
