package com.assignment.fourthDec2021;

public class Applicant {
    String name;
    String jobProfile;
    int age;

    public Applicant() {
    }

    public Applicant(String name, String jobprofile, int age) {
        this.name = name;
        this.jobProfile = jobprofile;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getJobProfile() {
        return jobProfile;
    }

    public void setJobProfile(String jobprofile) {
        this.jobProfile = jobprofile;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }


}
