package com.assignment.firstdec2021;

public class BillMain {
    String billid = "B9001";

    public static void main(String[] args) {


        Bill order1 = new Bill("DebitCard");
        order1.showBillDeatils();
        Bill order2 = new Bill("PayPal");
        order2.showBillDeatils();
    }
}
