package com.assignment.firstdec2021;

public class EmployeeMain {
    public static void main(String[] args) {

        Employee employee1 = new Employee(123, "Ram");
        employee1.setSalary(2000);
        employee1.getEmployeeid();
        employee1.getEmployeeName();
        employee1.showEmployeeDetails();
        Employee contracemp = new ContractEmployee(164, "Rahul", 6000, 30);
        contracemp.calculateSalary();
        contracemp.showEmployeeDetails();
        Employee permanentemp = new PermanentEmployee(130, "Anu", 20000, 10000, 2);
        permanentemp.calculateSalary();
        permanentemp.showEmployeeDetails();


    }
}
