package com.assignment.firstdec2021;

public class Camera {
    String cameraname;
    double price;
    int pixel;


    public Camera(String cameraname, double price, int pixel) {
        this.cameraname = cameraname;
        this.price = price;
        this.pixel = pixel;
    }


    public double getPrice() {

        return price;
    }

    public void setPrice(double price) {

        this.price = price;
    }

    public String getCameraname() {
        return cameraname;
    }

    public void setCameraname(String cameraname) {
        this.cameraname = cameraname;
    }

    public int getPixel() {
        return pixel;
    }

    public void setPixel(int pixel) {
        this.pixel = pixel;
    }

    public void ShowDetails() {

        System.out.println(cameraname + " " + price + " " + pixel);
    }


}
