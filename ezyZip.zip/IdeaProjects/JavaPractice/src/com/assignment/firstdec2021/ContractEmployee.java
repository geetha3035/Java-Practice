package com.assignment.firstdec2021;

public class ContractEmployee extends Employee {
    double wage;
    float hoursWorked;

    public ContractEmployee(int employeeid, String employeeName, double wage, float hoursWorked) {
        super(employeeid, employeeName);
        this.wage = wage;
        this.hoursWorked = hoursWorked;
    }

    public double getWage() {

        return wage;
    }

    public void setWage(double wage) {

        this.wage = wage;
    }

    public float getHoursWorked() {

        return hoursWorked;
    }

    public void setHoursWorked(float hoursWorked) {

        this.hoursWorked = hoursWorked;
    }

    @Override
    public void calculateSalary() {
        salary = getWage() + getHoursWorked();
    }

}

