package com.assignment.firstdec2021;

public class PermanentEmployee extends Employee {
    double basicPay;
    double hra;
    float experience;

    public PermanentEmployee(int employeeId, String employeeName, double basicPay, double hra, float experience) {
        super(employeeId, employeeName);
        this.basicPay = basicPay;
        this.hra = hra;
        this.experience = experience;
    }

    public double getBasicPay() {
        return basicPay;
    }

    public void setBasicPay(double basicPay) {
        this.basicPay = basicPay;
    }

    public double getHra() {
        return hra;
    }

    public void setHra(double hra) {
        this.hra = hra;
    }

    public float getExperience() {
        return experience;
    }

    public void setExperience(float experience) {
        this.experience = experience;
    }


    public double getSalary() {
        return super.getSalary();
    }

    @Override
    public void calculateSalary() {
        salary = getBasicPay() + getHra();
    }
}
