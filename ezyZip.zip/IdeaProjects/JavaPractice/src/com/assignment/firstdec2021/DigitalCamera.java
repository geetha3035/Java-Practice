package com.assignment.firstdec2021;

public class DigitalCamera extends Camera {

    public DigitalCamera(String cameraname, double price, int pixel) {
        super("Nikon", 0.0, 16);
        this.cameraname = cameraname;
        this.price = price;
        this.pixel = pixel;
    }

    public DigitalCamera() {
        super("Canon", 100.0, 16);
    }

    @Override
    public void ShowDetails() {
        System.out.println(cameraname + " " + price + " " + pixel);
    }


    public static void main(String[] args) {
//        DigitalCamera cam1= new DigitalCamera("Nikon",0.0,16);
//        cam1.ShowDetails();
        Camera cam2 = new DigitalCamera("Canon", 100.0, 16);
        cam2.ShowDetails();
    }
}