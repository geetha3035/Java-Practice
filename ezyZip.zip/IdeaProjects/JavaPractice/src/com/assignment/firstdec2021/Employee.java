package com.assignment.firstdec2021;

public class Employee {
    int employeeId;
    String employeeName;
    double salary;


    public Employee(int employeeId, String employeeName) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
    }

    public int getEmployeeid() {

        return employeeId;
    }

    public void setEmployeeid(int employeeId) {

        this.employeeId = employeeId;
    }

    public String getEmployeeName() {

        return employeeName;
    }


    public void setEmployeeNme(String employeeName) {

        this.employeeName = employeeName;
    }

    public double getSalary() {

        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void calculateSalary() {
        salary = getSalary();
    }
    public void showEmployeeDetails() {
        System.out.println(" Employee Details :- ");
        System.out.println(" Employee id : " + getEmployeeid());
        System.out.println(" Employee Name : " + getEmployeeName());
        System.out.println(" Employee Salary : " + getSalary());
    }

}
