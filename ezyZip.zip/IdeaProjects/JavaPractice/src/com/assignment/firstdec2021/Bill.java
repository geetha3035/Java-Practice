package com.assignment.firstdec2021;

public class Bill {
    static int counter = 0;
    String billid = "B9001";
    String paymentMode;
    String billidsetting;

    public Bill(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public int getCounter() {
        counter = counter + 1;
        return counter;
    }


    public String getBillid() {
        if (billid.length() == 5 && billid.startsWith("B900")) {
            String billidstr = billid.substring(1);
            int billidincre = Integer.parseInt(billidstr);
            billidincre = billidincre + 1;
            String billidtemp = Integer.toString(billidincre);
            billid = "B" + billidtemp;
        }
        return billid;
    }

    public void setBillid(String billid) {

        if (billid.length() == 5 && billid.startsWith("B900")) {
            this.billid = billid;
        }

    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public void showBillDeatils() {
        System.out.println("Bill Details");
        System.out.println("Order No: " + getCounter());
        System.out.println("Bill Id: " + getBillid());
        System.out.println("payment method: " + getPaymentMode());
    }


}