package com.assignment.twenty5nov2021;

import java.util.Scanner;

public class MakeAmount {

    public static void main(String[] args) {
        int no_of_five, no_of_one, rupees_to_make;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number of one rupees coins available: ");
        no_of_one = sc.nextInt();
        System.out.println("Enter number of five rupees coins available: ");
        no_of_five = sc.nextInt();
        System.out.println("Enter Amount of money to make: ");
        rupees_to_make = sc.nextInt();
        make_amount(rupees_to_make, no_of_five, no_of_one);

    }

    private static void make_amount(int rupees_to_make, int no_of_five, int no_of_one) {
        int five_needed = 0;
        int one_needed = 0;

        if (rupees_to_make > 1) {
            one_needed = rupees_to_make % 5;
            five_needed = rupees_to_make / 5;
            if (one_needed <= no_of_one && five_needed <= no_of_five) {
                System.out.println("No. of one  rupees needed :" + one_needed);
                System.out.println("No. of Five rupees needed :" + five_needed);
            } else {
                System.out.println("-1");
            }
        }else{
            System.out.println("invalid input");
        }

    }

}
