package com.assignment.twenty5nov2021;

import java.util.Scanner;

public class ProductOfNumbers {
    public static void main(String[] args) {
        int num1, num2, num3;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter two numbers: ");
        num1 = sc.nextInt();
        num2 = sc.nextInt();
        num3 = sc.nextInt();
        int product = find_product(num1, num2, num3);
        System.out.print(product);

    }
    private static int find_product(int num1, int num2, int num3) {
        int product = 1;
        if (num1 > 0 && num2 > 0 && num3 > 0) {
            if (num1 != 7 && num2 != 7 && num3 != 7) {
                product = num1 * num2 * num3;
            } else if (num1 != 7 && num2 != 7) {
                product = num1 * num2;
            } else {
                product = num3;
            }
            if (num2 != 7 && num3 != 7) {
                product = num2 * num3;
            } else if (num3 == 7) {
                product = -1;
            }
        } else {
            System.out.println("Invalid input ");
        }
        return product;
    }

}

