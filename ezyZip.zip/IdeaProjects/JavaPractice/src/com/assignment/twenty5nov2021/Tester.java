package com.assignment.twenty5nov2021;

import java.util.Scanner;

public class Tester {
    public static void main(String[] args) {
        int num1, num2, sum = 0, temp = 0;
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter two numbers: ");
        num1 = sc.nextInt();
        num2 = sc.nextInt();
        sum = num1 + num2;
        temp = sum;
        while (temp > 0) {
            int remainder = temp % 10;
            temp /= 10;
            if (temp == remainder) {
                sum = sum + sum;
            } else {
                sum = sum;
            }
        }
        System.out.println(sum);

    }
}
