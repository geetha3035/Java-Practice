package com.assignment.twenty5nov2021;


import java.util.Scanner;

class AreaOfCircle {

    public static void main(String[] args) {
        double radius, area;
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the radius of a circle: ");
        radius = sc.nextDouble();

        area = Math.PI * radius * radius;


        System.out.println("Area of a Circle = " + area);

    }
}