package com.assignment.twenty5nov2021;

import java.util.Scanner;

public class Triangle {

    public static void main(String[] args) {
        int side1, side2, side3;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter three sides of triangle ");
        side1 = sc.nextInt();
        side2 = sc.nextInt();
        side3 = sc.nextInt();
        String result = form_triangle(side1, side2, side3);
        if (result.equals("success")) {
            System.out.print("Triangle can be formed");
        } else {
            System.out.print("Triangle can't be formed");
        }

    }

    private static String form_triangle(int side1, int side2, int side3) {
        String result = "";
        if ((side1 + side2) > side3 && (side1 + side3) > side2 && (side2 + side3) > side1) {
            result = "success";
        } else {
            result = "failure";
        }
        return result;
    }
}